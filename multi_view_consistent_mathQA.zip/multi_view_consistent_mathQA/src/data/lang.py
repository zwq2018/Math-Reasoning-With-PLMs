import re
class Lang:
    """
    class to save the vocab and two dict: the word->index and index->word
    """
    def __init__(self):
        self.word2index = {}       #
        self.index2word = []       # word list
        self.n_words = 0  # Count word tokens
        self.num_start = 0

    def add_sen_to_vocab(self, sentence):  # add words of sentence to vocab
        for word in sentence:
            #['100.0', '1.0', '2.0', '3.0', '4.0', '10.0', '1000.0', '60.0', '0.5', '3600.0', '12.0', '0.2778','3.1416','3.6', '0.25', '5.0', '6.0', '360.0', '52.0', '180.0']
            if word == '100':
                word = '100.0'
            if word =='1':
                word = '1.0'
            if word == '2':
                word = '2.0'
            if word =='3':
                word = '3.0'
            if word == '4':
                word = '4.0'
            if word =='10':
                word = '10.0'
            if word == '1000':
                word = '1000.0'
            if word =='60':
                word = '60.0'
            if word =='3600':
                word = '3600.0'
            if word == '12':
                word = '12.0'
            if word == 'PI':
                word = '3.14'
            if word == '5':
                word = '5.0'
            if word == '6':
                word = '6.0'
            if word == '360':
                word = '360.0'
            if word == '52':
                word = '52.0'
            if word == '180':
                word = '180.0'

            if word not in self.index2word:
                self.word2index[word] = self.n_words
                self.index2word.append(word)
                self.n_words += 1


    def build_output_lang_for_tree(self):  # build the output lang vocab and dict处理输出词表 = copy num(18个) + constant(20个) + op(8个) +(2个括号符) + 'UNK'(1个)

        self.num_start = len(['+', '-', '-_rev', '*', '/', '/_rev'])      # 8 代表前8个全是op token，也带

        self.index2word =  ['+', '-', '-_rev', '*', '/', '/_rev','^', '^_rev']  + ['100.0', '1.0', '2.0', '3.0', '4.0', '10.0', '1000.0', '60.0', '0.5', '3600.0', '12.0', '0.2778','3.1416',
                     '3.6', '0.25', '5.0', '6.0', '360.0', '52.0', '180.0'] + ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v'] + ['(',')']+["UNK"]
        self.n_words = len(self.index2word)    # 23个decoder词汇一共

        for i, j in enumerate(self.index2word):
            self.word2index[j] = i

