
from src.utils import read_data, write_data
from collections import Counter
from tqdm import tqdm
from collections import defaultdict
from preprocess.mathqa_utils import parse_number, label2op,func2op, constants, parse_answer
from typing import List, Tuple
import re
from copy import deepcopy
import math
# \u03c0  -> pi

filtered_ops = {
'floor', 'choose', 'min', 'tangent', 'sine', 'reminder', 'lcm', 'factorial',
 'gcd', 'max', 'permutation', 'triangle_area_three_edges', 'surface_cylinder', 'rhombus_perimeter',
 'surface_rectangular_prism', 'speed_in_still_water', 'log', 'negate',
    ## following are not exists
    'round', 'cosine', 'circle_arc', 'degree_to_radians', 'radians_to_degree', 'sum_consecutive_number',
    'semi_circle_perimiter', 'circle_sector_area'## not exists
}



def subexp_idx_to_infix(subexp):

    var = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v']
    store_values = []

    for eq_idx, equation in enumerate(subexp):
        left_var, right_var, op = equation

        if left_var.startswith('m_'):
            index  = int(left_var[-1])-1
            left_number = store_values[index]
        elif left_var in var:  #
            left_number = 'temp_' + left_var
        else:
            left_number = left_var

        if right_var.startswith('m_'):
            index  = int(right_var[-1]) - 1
            right_number = store_values[index]
        elif right_var in var:
            right_number = 'temp_' + right_var
        else:#
            right_number = right_var

        if isinstance(left_number, str):
            left = []
            left.append(left_number)
            left_number = left

        if isinstance(right_number, str):
            right = []
            right.append(right_number)
            right_number = right


        if op.endswith("_rev"):
            current_exp = right_number + [op[:-4]] + left_number
        else:
            current_exp = left_number + [op] + right_number

        current_exp = ['('] + current_exp + [')']
        store_values.append(current_exp)

    return current_exp[1:-1]


def from_infix_to_prefix(exp):
    st = list()
    res = list()
    priority = {"+": 0, "-": 0, "*": 1, "/": 1, "^": 2}
    expression = deepcopy(exp)
    expression.reverse()
    for e in expression:
        if e in [")", "]"]:
            st.append(e)
        elif e == "(":
            c = st.pop()
            while c != ")":
                res.append(c)
                c = st.pop()
        elif e == "[":
            c = st.pop()
            while c != "]":
                res.append(c)
                c = st.pop()
        elif e in priority:
            while len(st) > 0 and st[-1] not in [")", "]"] and priority[e] < priority[st[-1]]:
                res.append(st.pop())
            st.append(e)
        elif e.startswith("temp_"):
            res.append(e)
        else:
            res.append(e)
    while len(st) > 0:
        res.append(st.pop())
    res.reverse()
    return res



def replace_question(problem_string:str ,  spans: List[Tuple]):
    new_problem = []
    current_num_idx = 0
    current_span = spans[current_num_idx]
    char_idx = 0
    while char_idx < len(problem_string):
        if current_span is not None and char_idx == current_span[0]:
            new_problem.append(f" temp_{chr(ord('a') + current_num_idx)} ")
            char_idx += current_span[1] - current_span[0]
            current_num_idx += 1
            current_span = spans[current_num_idx] if current_num_idx < len(spans) else None
            continue
        else:
            new_problem.append(problem_string[char_idx])
        char_idx += 1
    new_problem = ''.join(new_problem)
    return new_problem

def get_var(arg_var):
    if arg_var.startswith("const_"):
        return constants[arg_var]
    elif arg_var.startswith("n"):
        num_idx = int(arg_var[1:])
        return f"temp_{chr(ord('a') + num_idx)}"
    elif arg_var.startswith("#"):
        num_idx = int(arg_var[1:])
        return f"globalm_{num_idx}"
    else:
        raise NotImplementedError(f"not implemented for variable: {arg_var}")

def get_processed_equation(equation: str, intermediate_offset:int, current_equation_idx: int):
    eles = equation.split(",")
    op_name = eles[0].split("(")[0]
    args_a = eles[0].split("(")[1]
    args = [args_a]
    eq_num = 0
    if len(eles) > 1:
        if len(eles) == 2:
            assert eles[1].endswith(")")
            args.append(eles[1][:-1])
        elif len(eles) == 3:
            assert eles[2].endswith(")")
            args.append(eles[1])
            args.append(eles[2][:-1])
    else:
        args[0] = args[0][:-1] ## to remove the final )
    modified_op_name = func2op[op_name]
    if isinstance(modified_op_name, str):
        operator = label2op[modified_op_name]
        label = [[get_var(args[0]), get_var(args[1]), operator]]
        eq_num = 1
    elif isinstance(modified_op_name, Tuple):
        operator = label2op[modified_op_name[0]]
        vars = []
        for name in [modified_op_name[1], modified_op_name[2]]:
            if isinstance(name, str) and name.startswith("temp_"):
                var_idx = ord(name.replace("temp_", "")) - ord('a')
                current_arg = args[var_idx]
                current_var = get_var(current_arg)
            else:
                current_var = name if name != 'const_pi' else constants[name]
                assert isinstance(current_var, float) or isinstance(current_var, int)
            vars.append(current_var)
        label = [vars + [operator]]
        eq_num = 1
    elif isinstance(modified_op_name, list):
        label = []
        for t_idx, eq_tuple in enumerate(modified_op_name):
            operator = label2op[eq_tuple[0]]
            vars = []
            for name in [eq_tuple[1], eq_tuple[2]]:
                if isinstance(name, str) and name.startswith("temp_"):
                    var_idx = ord(name.replace("temp_", "")) - ord('a')
                    current_arg = args[var_idx]
                    current_var = get_var(current_arg)
                elif isinstance(name, str) and name.startswith("m_"):
                    current_var = name.replace("m_", "localm_")

                else:
                    current_var = name if name != 'const_pi' else constants[name]
                    assert isinstance(current_var, float) or isinstance(current_var, int)
                vars.append(current_var)
            current_label = vars + [operator]
            label.append(current_label)
        eq_num = len(modified_op_name)
    else:
        raise NotImplementedError(f"not implemented for type: {modified_op_name}")

    return label, intermediate_offset, eq_num

def check_maximum_num_list(equations: List[str]):
    max_idx = -1
    for eq_idx, equation in enumerate(equations):
        assert equation.endswith(")")
        start = equation.index("(")
        var_str = equation[start+1:-1]
        var_list = var_str.split(",")
        for var in var_list:
            if var.startswith("n"):
                max_idx = max(int(var.replace("n", "")), max_idx)
    return max_idx

def convert_equations(equations: List[str]):
    all_equation_layers = []
    for eq_idx, equation in enumerate(equations):
        sub_equations, intermediate_offset, sub_eq_num = get_processed_equation(equation=equation, intermediate_offset=0, current_equation_idx=eq_idx)
        all_equation_layers.append(sub_equations)
    ## post process, first, update_global_m first
    accumulate_prev_extra  = [0]
    accumulate_prev_all = [0]
    for global_idx, global_equations in enumerate(all_equation_layers):
        accumulate_prev_extra.append(len(global_equations) - 1 + accumulate_prev_extra[global_idx])
        accumulate_prev_all.append(len(global_equations) + accumulate_prev_all[global_idx])
    accumulate_prev_extra = accumulate_prev_extra[1:]
    accumulate_prev_all = accumulate_prev_all[:-1]
    for global_idx, global_equations in enumerate(all_equation_layers):
        for local_idx, sub_equation in enumerate(global_equations):
            for idx, var in enumerate([sub_equation[0], sub_equation[1]]):
                if isinstance(var, str) and var.startswith("globalm_"):
                    sub_equation[idx] = f"globalm_{accumulate_prev_extra[int(var.replace('globalm_', ''))] + int(var.replace('globalm_', ''))}"
    ## now update the localm
    for global_idx, global_equations in enumerate(all_equation_layers):
        for local_idx, sub_equation in enumerate(global_equations):
            for idx, var in enumerate([sub_equation[0], sub_equation[1]]):
                if isinstance(var, str) and var.startswith("localm_"):
                    sub_equation[idx] = f"globalm_{accumulate_prev_all[global_idx] + int(var.replace('localm_', ''))}"
    all_equation_layers = [equation for equation_layer in all_equation_layers for equation in equation_layer]
    for global_idx, global_eq in enumerate(all_equation_layers):
        for idx, var in enumerate([global_eq[0], global_eq[1]]):
            if isinstance(var, str) and var.startswith("globalm_"):
                global_eq[idx] = f"m_{int(var.replace('globalm_', ''))}"
    return all_equation_layers


def process_options_and_answers(option_string, answer_string):
    options = [item for item in re.findall('[a-e] \) ([^,]*)', option_string)]
    current_answer_string_in_option = options[ord(answer_string) - ord('a')]
    answer= parse_answer(current_answer_string_in_option)
    if answer == "none":
        # print(option_string, answer)
        return None
    if answer.endswith(" / 00"):
        answer = answer.replace(" / 00", "").strip()
    try:
        return eval(answer)
    except:
        # print(option_string, answer)
        return None
    # print(answer, eval(answer))


def process_all_question(all_equation_layers):
    labels = all_equation_layers
    for i, (left, right, op) in enumerate(all_equation_layers):
        left, right = str(left), str(right)
        if left.startswith("m_") or right.startswith("m_"):
            if left.startswith("m_") and right.startswith("m_"):
                left_is_smaller = (ord(left[-1:]) - ord(right[-1:])) <= 0
                modified_op = op + "_rev" if op in {'-', '/', '**'} and (not left_is_smaller) else op
                labels[i] = [left, right, modified_op] if left_is_smaller else [right, left, modified_op]
            elif right.startswith("m_"):
                modified_op = op + "_rev" if op in {'-', '/', '**'} else op
                labels[i] = [right, left, modified_op]
                if not left.startswith("temp_"):
                    labels[i] = [right, str(float(left)), modified_op]
                    const_list.add(str(float(left)))
                    const2num[str(float(left))] += 1
            else:
                if not right.startswith("temp_"):
                    labels[i] = [left, str(float(right)), op]
                    const_list.add(str(float(right)))
                    const2num[str(float(right))] += 1
        else:
            if left.startswith("temp_") or right.startswith("temp_"):
                if left.startswith("temp_") and right.startswith("temp_"):
                    left_is_smaller = (ord(left[-1:]) - ord(right[-1:])) <= 0
                    modified_op = op + "_rev" if op in {'-', '/', '**'} and (not left_is_smaller) else op
                    labels[i] = [left, right, modified_op] if left_is_smaller else [right, left, modified_op]
                elif right.startswith("temp_"):
                    modified_op = op + "_rev" if op in {'-', '/', '**'} else op
                    labels[i] = [right, str(float(left)), modified_op]
                    const_list.add(str(float(left)))
                    const2num[str(float(left))] += 1
                else:
                    labels[i] = [left, str(float(right)), op]
                    const_list.add(str(float(right)))
                    const2num[str(float(right))] += 1
            else:
                labels[i] = [str(float(left)), str(float(right)), op]
                const_list.add(str(float(left)))
                const_list.add(str(float(right)))
                const2num[str(float(left))] += 1
                const2num[str(float(right))] += 1
                pass

    for i, (left, right, op) in enumerate(labels):
        left = left[-1:] if left.startswith("temp_") else left
        right = right[-1:] if right.startswith("temp_") else right
        if left.startswith("m_"):
            left = f"m_{int(left.replace('m_', '')) + 1}"
        if right.startswith("m_"):
            right = f"m_{int(right.replace('m_', '')) + 1}"
        if op.startswith("**"):
            op = op.replace("**", "^")
        labels[i] = [left, right, op]

def process_obj(obj):
    linear_formula = obj["linear_formula"]
    problem_string = obj["Problem"]
    equations = linear_formula.split("|")
    equations = [eq for eq in equations if eq.strip() != '']
    num_list, spans = parse_number(problem_string)
    new_problem = replace_question(problem_string, spans) if len(spans) > 0 else problem_string
    obj["text"] = new_problem
    obj["num_list"] = num_list
    total_nums = check_maximum_num_list(equations) + 1
    assert len(num_list) >= total_nums

    type_str = "legal"
    obj["type_str"] = "legal"
    for equation in equations:
        eles = equation.split(",")

        op_name = eles[0].split("(")[0]
        if op_name in filtered_ops:
            type_str = "illegal_operator"
            # print(obj["id"])
            break
    if type_str != "legal":
        obj["type_str"] = type_str
        # print(obj["id"])
        return obj
    all_equation_layers = convert_equations(equations)
    # print()
    obj["equation_layer"]= all_equation_layers
    process_all_question(all_equation_layers)
    return obj

def process_file(file:str):
    data = read_data(file=file)
    out_file = file.split(".json")[0] + ".json"
    invalid_ans = 0
    total_legal = 0
    for idx, obj in tqdm(enumerate(data), desc=f"Reading {file}", total=len(data)):
        ans = process_options_and_answers(obj["options"].strip(), obj["correct"].strip())
        obj["answer"] = float(ans) if ans is not None else None
        obj = process_obj(obj)
        if ans is None:
            invalid_ans +=1
            obj["type_str"] = "invalid_answer"
        total_legal += 1 if obj["type_str"] == "legal" else 0
        equ_lay = obj['equation_layer']
        obj['target_template'] = ['X','='] + subexp_idx_to_infix(equ_lay)
        obj['pre_target_template'] = ['X','='] +  from_infix_to_prefix(subexp_idx_to_infix(equ_lay))

    print(f"number of invalid ans: {invalid_ans}, total legal: {total_legal} out of all: {len(data)}")
    write_data(file=out_file, data=data)
    print(const_list)
    sorted_counter = sorted(const2num.items(), key=lambda kv: (kv[1], kv[0]), reverse=True)
    print(sorted_counter)
    print([k[0] for k in sorted_counter])
    const_list.clear()
    const2num.clear()

def get_stat(file:str):
    data = read_data(file=file)
    argnum2num = Counter()
    equation_num = Counter()
    num_valid = 0
    unique_operations = set()
    subject2op = defaultdict(set)
    for obj in tqdm(data, desc=f"Reading {file}", total=len(data)):
        linear_formula = obj["linear_formula"]
        equations = linear_formula.split("|")
        equations = [eq for eq in equations if eq.strip() != '']
        equation_num[len(equations)] += 1
        valid = True
        for equation in equations:
            eles = equation.split(",")
            op_name = eles[0].split("(")[0]
            if len(eles) != 1 and len(eles) !=2:
                valid = False
            if op_name in filtered_ops:
                valid = False
            else:
                if op_name == '':
                    print(obj)
                unique_operations.add(op_name)
                subject2op[obj['category']].add(op_name)
            argnum2num[len(eles)] +=1
        type_str = "legal" if valid else "illegal"
        num_valid += 1 if valid else 0
    print(f"Total numner: {len(data)}")
    print(f"equation num: {equation_num}")
    print(f"arg num num: {argnum2num}")
    print(f" valid  num {num_valid} out of total: {len(data)}")
    print(f"unique operations num: {len(unique_operations)}\n operations: {unique_operations}")




def trans_equ(exa):

    add_sub = ['+', '-']
    mul_div = ['*', '/']
    lp = ['(', '[']
    rp = [')', ']']
    old_exa =deepcopy(exa)

    change_flag = False
    for i, x in enumerate(exa):

        if x == '(' and exa[i + 2] in add_sub and exa[i + 4] in rp:
            left = exa[i + 1]
            op = exa[i + 2]
            right = exa[i + 3]

            if i - 2 >= 0 and exa[i - 1] in mul_div and len(exa) > i + 5 and exa[i + 5] in mul_div:
                break
            if exa[i-3] =='/' and exa[i-1] =="*" :
                break

            elif i - 2 >= 0 and exa[i - 2] not in rp and exa[i - 1] =='*' :
                if len(exa)>i+5 and exa[i+5] not in mul_div :
                    temp = ['(',exa[i - 2], exa[i - 1], left, op, exa[i - 2], exa[i - 1], right,')']
                    exa = exa[:i - 2] + temp + exa[i + 5:]
                    change_flag = True
                elif len(exa)<=i+5:
                    temp = ['(',exa[i - 2], exa[i - 1], left, op, exa[i - 2], exa[i - 1], right,')']
                    exa = exa[:i - 2] + temp
                    change_flag = True

            elif len(exa)>i+5 and exa[i + 5] in mul_div and exa[i + 6] not in lp and exa[i - 1] not in mul_div:
                temp = ['(',left, exa[i + 5], exa[i + 6], op, right, exa[i + 5], exa[i + 6],')']
                exa = exa[:i] + temp + exa[i + 7:]
                change_flag = True


    return exa, change_flag


def out_expression_list(equ, num_list):
    res=[]
    for x in equ:
        if x.startswith('temp_'):
            xx = x[-1]
            idx = ord(str(xx))-ord(str('a'))
            num = num_list[idx]
            res.append(str(num))
        else:
            res.append(str(x))
    return res



def compute_prefix_expression(pre_fix):
    st = list()
    operators = ["+", "-", "^", "*", "/"]
    pre_fix = deepcopy(pre_fix)
    pre_fix.reverse()
    for p in pre_fix:
        if p not in operators:
            pos = re.search("\d+\(", p)
            if pos:
                st.append(eval(p[pos.start(): pos.end() - 1] + "+" + p[pos.end() - 1:]))
            elif p[-1] == "%":
                st.append(float(p[:-1]) / 100)
            elif p=='PI'or p=='pi':
                st.append(eval('3.14'))
            else:
                st.append(eval(p))
        elif p == "+" and len(st) > 1:
            a = st.pop()
            b = st.pop()
            st.append(a + b)
        elif p == "*" and len(st) > 1:
            a = st.pop()
            b = st.pop()
            st.append(a * b)
        elif p == "*" and len(st) > 1:
            a = st.pop()
            b = st.pop()
            st.append(a * b)
        elif p == "/" and len(st) > 1:
            a = st.pop()
            b = st.pop()
            if b == 0:
                return None
            st.append(a / b)
        elif p == "-" and len(st) > 1:
            a = st.pop()
            b = st.pop()
            st.append(a - b)
        elif p == "^" and len(st) > 1:
            a = st.pop()
            b = st.pop()

            st.append(a ** b)
        else:
            return None
    if len(st) == 1:
        return st.pop()
    return None


def check_in_labels(current_tuple, labels):
    if current_tuple in labels:
        return current_tuple
    if current_tuple[-1] in {'+', '*'} and [current_tuple[1], current_tuple[0], current_tuple[-1]] in labels:
        return [current_tuple[1], current_tuple[0], current_tuple[-1]]
    return None


def get_labels_with_align(target_template: List, remove_duplicate: bool = False, obj =None):

    prefix_temp = from_infix_to_prefix(target_template[2:])
    if len(prefix_temp) == 1:
        assert prefix_temp[0].startswith("temp_")
        prefix_temp=["*","1"] + prefix_temp


    stack = []
    pointer = len(prefix_temp)-1
    labels = []
    both_m = False
    eq_2_m = {}
    got_duplicate = False
    alig=[-1]*len(prefix_temp)
    while pointer >= 0:
        stack.append(prefix_temp[pointer])
        if stack[-1] in {'+', '-', '*', '/', '^'}:
            if len(stack[-3:]) == 3:
                if stack[-3].startswith("m_") and stack[-2].startswith("m_"):
                    both_m = True
                if remove_duplicate:
                    checker = check_in_labels([stack[-2], stack[-3], stack[-1]], labels)
                    if checker:
                        got_duplicate = True
                        m_string = eq_2_m[' '.join(checker)]
                        alig[pointer] = int(m_string[2:]) - 1
                    else:
                        labels.append([stack[-2], stack[-3], stack[-1]])
                        m_string = f"m_{len(labels)}"
                        eq_2_m[' '.join([stack[-2], stack[-3], stack[-1]])] = m_string
                        alig[pointer] = len(labels)-1

                else:
                    labels.append([stack[-3], stack[-2], stack[-1]])
                    m_string = f"m_{len(labels)}"
                stack.pop()
                stack.pop()
                stack.pop()
                stack.append(m_string)
        pointer -= 1
    for i, (left, right, op) in enumerate(labels):
        if left.startswith("m_") or right.startswith("m_"):
            if left.startswith("m_") and right.startswith("m_"):
                left_is_smaller = (ord(left[-1:]) - ord(right[-1:])) <= 0
                modified_op = op + "_rev" if op in {'-', '/', '^'} and (not left_is_smaller) else op
                labels[i] = [left, right, modified_op] if left_is_smaller else [right, left, modified_op]
            elif right.startswith("m_"):
                modified_op = op + "_rev" if op in {'-', '/', '^'} else op
                labels[i] = [right, left, modified_op]
        else:
            if left.startswith("temp_") or right.startswith("temp_"):
                if left.startswith("temp_") and right.startswith("temp_"):
                    left_is_smaller = (ord(left[-1:]) - ord(right[-1:])) <= 0
                    modified_op = op + "_rev" if op in {'-', '/', '^'} and (not left_is_smaller) else op
                    labels[i] = [left, right, modified_op] if left_is_smaller else [right, left, modified_op]
                elif right.startswith("temp_"):
                    modified_op = op + "_rev" if op in {'-', '/', '^'} else op
                    labels[i] = [right, left, modified_op]
                else:
                    pass

            else:
                pass

    for i, (left, right, op) in enumerate(labels):                       #
        left = left[-1:] if left.startswith("temp_") else left
        right = right[-1:] if right.startswith("temp_") else right
        labels[i] = [left, right, op]

    temp_var_list = [v for v in target_template if v.startswith("temp_")]
    gap = 0
    if len(temp_var_list) != 0:

        max_temp_org = max([v for v in target_template if v.startswith("temp_")])

    return labels, both_m, gap, got_duplicate, alig



def precess2_file():
    add_new_flag = 1
    for in_file in ["mathqa_train"]:
        print(f"working on... {in_file}")
        in_file = f"../data/MathQA/{in_file}" + ".json"
        out_file = in_file.split(".json")[0] + "multi_view_align.json"
        data = read_data(in_file)
        count = Counter()
        temp = []
        duplicate_num = 0
        for obj in tqdm(data, desc="processing data", total=len(data)):
            res_multi_equ, change_flag = trans_equ(obj["target_template"][2:] )
            prefix_multi_equ = from_infix_to_prefix(res_multi_equ)
            prefix_normal_equ = from_infix_to_prefix(obj["target_template"][2:])
            num_list = obj['num_list']
            ans_gold = obj['answer']
            prefix_multi_equ_num = out_expression_list(prefix_multi_equ, num_list)
            prefix_normal_equ_num = out_expression_list(prefix_normal_equ, num_list)
            ans1_multi = compute_prefix_expression(prefix_multi_equ_num)
            ans2_normal = compute_prefix_expression(prefix_normal_equ_num)


            labels, _, _, got_duplicate, align = get_labels_with_align(obj["target_template"], True)

            obj['copy'] = 'origin equation'
            obj['equation_layer'] = labels
            obj['align'] = align
            obj['duplicate'] = got_duplicate
            duplicate_num += 1 if got_duplicate else 0

            if change_flag and  math.fabs(ans1_multi - ans2_normal) <= 1e-4 and add_new_flag:
                count['multi_equ_infix'] += 1
                obj_new = deepcopy(obj)
                obj_new['copy'] = 'new equation'
                obj_new["target_template"][2:] = res_multi_equ
                obj_new["pre_target_template"][2:] = prefix_multi_equ

                labels_multi_equ, _, _, got_duplicate_new, align_new = get_labels_with_align(obj_new["target_template"], True)
                obj_new["equation_layer"] = labels_multi_equ
                obj_new["align"] = align_new
                duplicate_num += 1 if got_duplicate_new else 0
                obj_new['duplicate'] = got_duplicate_new
                temp.append(obj)
                temp.append(obj_new)
            else:
                temp.append(obj)


        write_data(file=out_file, data = temp)
        print(f" duplication number: {duplicate_num}")

        for key in count:
            print(f"{key}, valid number: {count[key]}, total: {len(data)}, %: {count[key] * 1.0 / len(data) * 100:.2f}")
        print(const_list)
        const_list.clear()
        print(sorted(const2num.items(), key=lambda kv: (kv[1], kv[0]), reverse=True))
        const2num.clear()




if __name__ == '__main__':
    const_list = set()
    const2num = Counter()
    precess2_file()